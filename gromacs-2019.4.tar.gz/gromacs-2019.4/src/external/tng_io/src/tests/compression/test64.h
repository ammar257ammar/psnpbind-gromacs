#define TESTNAME "Coding. Read int and convert to float."
#define FILENAME "test64.tng_compress"
#define ALGOTEST
#define NATOMS 1000
#define CHUNKY 100
#define SCALE 0.1
#define PRECISION 0.01
#define WRITEVEL 1
#define VELPRECISION 0.1
#define INITIALCODING 5
#define INITIALCODINGPARAMETER 0
#define CODING 5
#define CODINGPARAMETER 0
#define INITIALVELCODING 3
#define INITIALVELCODINGPARAMETER -1
#define VELCODING 3
#define VELCODINGPARAMETER -1
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 10000
#define INTMAX2 10000
#define INTMAX3 10000
#define NFRAMES 100
#define INTTOFLOAT
#define TEST_FLOAT
#define EXPECTED_FILESIZE 698801.
