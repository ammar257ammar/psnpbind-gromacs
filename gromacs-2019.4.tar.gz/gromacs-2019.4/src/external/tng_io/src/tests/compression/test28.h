#define TESTNAME "Initial coding. Autoselect algorithm. Repetitive molecule. Cubic cell."
#define FILENAME "test28.tng_compress"
#define ALGOTEST
#define NATOMS 1000
#define CHUNKY 1
#define SCALE 0.1
#define REGULAR
#define PRECISION 0.01
#define WRITEVEL 0
#define VELPRECISION 0.1
#define INITIALCODING -1
#define INITIALCODINGPARAMETER -1
#define CODING 0
#define CODINGPARAMETER 0
#define INITIALVELCODING 0
#define INITIALVELCODINGPARAMETER -1
#define VELCODING 0
#define VELCODINGPARAMETER 0
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 10000
#define INTMAX2 10000
#define INTMAX3 10000
#define NFRAMES 1000
#define EXPECTED_FILESIZE 1677619.
